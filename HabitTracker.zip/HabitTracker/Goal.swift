//
//  Goal.swift
//  HabitTracker
//
//  Created by ieX Lab 4_13 on 17/07/2019.
//  Copyright © 2019 iMac7. All rights reserved.
//
import Foundation
struct Goal: Codable{
    static let sharedInstance = DatabaseAccessor()
    var name: String="";
    var description: String="";
    init(n: String,ds: String){
        self.name=n
        self.description=ds
    }
    func getname()
    {
        print(self.name)
    }
    
}
