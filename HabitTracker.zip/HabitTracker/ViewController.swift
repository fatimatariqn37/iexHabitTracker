//
//  ViewController.swift
//  HabitTracker
//
//  Created by ieX Lab 4_13 on 02/07/2019.
//  Copyright © 2019 iMac7. All rights reserved.
//

import UIKit
//import SQLite

class ViewController: UIViewController{
   
    override func viewDidLoad() {
        super.viewDidLoad()
        print("Going to start app")
        // Do any additional setup after loading the view.
    }
    
   
   
   
}

