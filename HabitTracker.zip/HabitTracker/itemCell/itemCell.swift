//
//  itemCell.swift
//  HabitTracker
//
//  Created by ieX Lab 4_14 on 29/07/2019.
//  Copyright © 2019 iMac7. All rights reserved.
//

import UIKit

class itemCell: UICollectionViewCell {
 
    
    @IBOutlet weak var textLabel: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
    func setData(text: String){
        self.textLabel.text = text
        
        
    }
}
