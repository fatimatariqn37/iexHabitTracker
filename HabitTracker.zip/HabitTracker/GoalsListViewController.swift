//
//  GoalsListViewController.swift
//  HabitTracker
//
//  Created by ieX Lab 4_13 on 25/07/2019.
//  Copyright © 2019 iMac7. All rights reserved.
//

import UIKit

class GoalsListViewController: UIViewController, UITableViewDataSource {
    
    
    
    let goals=[
        ("Drink Water","Daily"),
        ("Have a healthy diet","Daily"),
        ("Study","Daily"),
        ("Namaz","Daily")
    ]
    
    
    //
    //var gg=Goal()
    func filldb(){
        var mygoals:[Goal] = []
        var g1=Goal(n: "Namaz",ds: "Daily");
        var g2=Goal(n: "Study",ds: "Daily");
        var g3=Goal(n: "Meeting",ds: "Weekly");
        mygoals.append(g1)
        mygoals.append(g2)
        mygoals.append(g3)
        var cat1=Category(catgoals: mygoals)
        var mydb=DatabaseAccessor()
        mydb.createConnection()
        mydb.createGoalCategoryTables()
        mydb.insertIntoCategory(cname: "Duas", cdesc: "Making habit of daily duas")
        mydb.insertIntoCategory(cname: "Diet", cdesc: "Healthy diet leads to healthy life")
        mydb.InsertIntoGoal(g_name: "Morning Dua", g_desc: "Start your day with dua", g_cat: 1)
    }
    
    
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        return goals.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell=UITableViewCell()
        var (habit,type)=goals[indexPath.row]
        cell.textLabel?.text=(habit)
        if (indexPath.row % 2 == 0)
        {
            
            cell.backgroundColor = #colorLiteral(red: 0.1019607857, green: 0.2784313858, blue: 0.400000006, alpha: 1)
        } else {
            cell.backgroundColor = #colorLiteral(red: 0, green: 0.5, blue: 0.5921568871, alpha: 1)
        }
        
        
        return cell
        /*cell.textLabel?.text="Drink Water"
         return cell*/
        
    }
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        print("This is goals list view controller")
        filldb()
        // Do any additional setup after loading the view.
    }
    
    
    
    
}
