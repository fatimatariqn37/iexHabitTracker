//
//  DatabaseAccessor.swift
//  HabitTracker
//
//  Created by ieX Lab 4_13 on 29/07/2019.
//  Copyright © 2019 iMac7. All rights reserved.
//

import Foundation
import UIKit
import SQLite

class DatabaseAccessor{
    var connection:Connection!
    init(){
        
    }
    func createConnection() -> Bool
    {
        do{
            //let path1=Bundle.main.resourceURL?.appendingPathComponent("/Users/imac7/Desktop/HabitTracker/HabitTracker/Habit.db").path
            let path1="/Users/iex-lab1/Downloads/HabitTracker-5/HabitTracker/Habit.db"
            
            connection=try Connection(path1)
            
            print(path1)
            return true
        }
        catch{
            print ("DB not connected")
            return false
        }
    }
    
    
    
    func createGoalCategoryTables()
    {
        let catg = Table("Category")
        let id = Expression<Int64>("Id")
        let name = Expression<String?>("Name")
        let desc = Expression<String>("Description")
        
        do{
            try connection.run(catg.create { t in
                t.column(id, primaryKey: true)
                t.column(name)
                t.column(desc, unique: true)
                print ("Table Catreory created")
            })
            //return true
        }
        catch{
            print ("Table Category not created")
            //return false
        }
        let goal = Table("Goal")
        let gid = Expression<Int64>("Id")
        let gname = Expression<String?>("Name")
        let gdesc = Expression<String>("Description")
        let gcat = Expression<Int64>("CategoryID")
        do{
            try connection.run(goal.create { t in
                t.column(gid, primaryKey: true)
                t.column(gname)
                t.column(gdesc, unique: true)
                t.column(gcat)
                t.foreignKey(gcat, references: catg,id)
                print ("Table Goal created")
            })
            //return true
        }
        catch{
            print ("Table Goal not created")
            //return false
        }
    }
    
    func insertIntoCategory(cname: String, cdesc: String)
    {
        let catg = Table("Category")
        let id = Expression<Int64>("Id")
        let name = Expression<String?>("Name")
        let desc = Expression<String>("Description")
        var insert = catg.insert(name <- cname, desc <- cdesc)
        do{
            let rowid = try connection.run(insert)
        }
        catch{
            print("Record not inserted")
        }
    }
    
    func InsertIntoGoal(g_name: String,g_desc: String,g_cat: Int64)
    {
        let goal = Table("Goal")
        let gid = Expression<Int64>("Id")
        let gname = Expression<String?>("Name")
        let gdesc = Expression<String>("Description")
        let gcat = Expression<Int64>("CategoryID")
        var insert = goal.insert(gname <- g_name, gdesc <- g_desc,gcat <- g_cat)
        do{
            let rowid = try connection.run(insert)
        }
        catch{
            print("Record not inserted")
        }
    }
    
    
    
    func createTable() -> Bool
    {
        
        let users = Table("users")
        let id = Expression<Int64>("id")
        let name = Expression<String?>("name")
        let email = Expression<String>("email")
        
        let course = Table("course")
        let cid = Expression<Int64>("c_id")
        let cname = Expression<String?>("c_name")
        /*do{
         try connection.run(users.create { t in
         t.column(id, primaryKey: true)
         t.column(name)
         t.column(email, unique: true)
         print ("Table created")
         })*/
        
        
        /*do{
         try connection.run(course.create { t in
         t.column(cid, primaryKey: true)
         t.column(cname)
         print ("Course Table created")
         })*/
        
        //var insert2 = course.insert(cname <- "Data")
        do {
            
            /*    var insert2 = users.insert(name <- "oop", email <- "oop@mac.com")
             let rowid = try connection.run(insert2)  */
            // INSERT INTO "users" ("name", "email") VALUES ('Alice', 'alice@mac.com')
            
            for user in try connection.prepare(users) {
                print("id: \(user[id]), name: \(user[name]), email: \(user[email])")
                // id: 1, name: Optional("Alice"), email: alice@mac.com
            }
            /*for cour in try connection.prepare(course) {
             print("id: \(cour[cid]), name: \(cour[cname])")
             // id: 1, name: Optional("Alice"), email: alice@mac.com
             }*/
            return true
        }
        catch{
            print ("Table not created")
            return false
        }
        
        
    }
}

