//
//  goalLibraryCell.swift
//  HabitTracker
//
//  Created by ieX Lab 4_14 on 26/07/2019.
//  Copyright © 2019 iMac7. All rights reserved.
//

import UIKit

class goalLibraryCell: UICollectionViewCell {
    
    @IBOutlet weak var cellLabel: UIButton!
    
    
}
