//
//  GoalLibraryViewController.swift
//  HabitTracker
//
//  Created by ieX Lab 4_13 on 26/07/2019.
//  Copyright © 2019 iMac7. All rights reserved.



//
//  GoalLibraryViewController.swift
//  HabitTracker
//
//  Created by ieX Lab 4_13 on 26/07/2019.
//  Copyright © 2019 iMac7. All rights reserved.
//

import UIKit

class GoalLibraryViewController: UIViewController {
    let Cat1Goals=[
        ("Drink Water","Daily"),
        ("Eat 3 times a day","Daily"),
        ("Have healthy diet","Daily")
    ]
    // let Cat1=Category(from: Cat1Goals)
    
    //Cat1.goals=Cat1Goals
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
    }
    
    
    /*
     // MARK: - Navigation
     
     // In a storyboard-based application, you will often want to do a little preparation before navigation
     override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
     // Get the new view controller using segue.destination.
     // Pass the selected object to the new view controller.
     }
     */
    
}






//
/*
import UIKit

class GoalLibraryViewController: UIViewController,UICollectionViewDataSource{
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return 3
    
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell
    {
        let cell=UICollectionViewCell()
       
        //cell.textLabel?.text=("aa")
        cell.backgroundColor = #colorLiteral(red: 0.8785521388, green: 0.4855040908, blue: 0.4625179172, alpha: 0.8935959507)
        
        return cell
        
    }
    

    @IBOutlet weak var collectionView: UICollectionView!
    override func viewDidLoad() {
        super.viewDidLoad()
        collectionView.dataSource = self as UICollectionViewDataSource
        // Do any additional setup after loading the view.
    }
    /*
    let totalColors: Int = 100
    func colorForIndexPath(indexPath: NSIndexPath) -> UIColor {
        if indexPath.row >= totalColors {
            return UIColor.blackColor()    // return black if we get an unexpected row index
        }
        
        var hueValue: CGFloat = CGFloat(indexPath.row) / CGFloat(totalColors)
        return UIColor(hue: hueValue, saturation: 1.0, brightness: 1.0, alpha: 1.0)
    }

    @implementation ViewController
    
    int totalColors = 100;
    - (UIColor*)colorForIndexPath:(NSIndexPath *) indexPath{
    if(indexPath.row >= totalColors){
    return UIColor.blackColor;    // return black if we get an unexpected row index
    }
    
    CGFloat hueValue = (CGFloat)(indexPath.row)/(CGFloat)(totalColors);
    return [UIColor colorWithHue:hueValue saturation:1.0 brightness:1.0 alpha:1.0];
    }
    @end

*/
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
*/
