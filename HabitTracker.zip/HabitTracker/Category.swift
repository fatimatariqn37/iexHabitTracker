//
//  Category.swift
//  HabitTracker
//
//  Created by ieX Lab 4_13 on 17/07/2019.
//  Copyright © 2019 iMac7. All rights reserved.
//


import Foundation

struct Category: Codable {
    static let sharedInstance = DatabaseAccessor()
    let goals: [Goal]
    init(catgoals: [Goal]) {
        //self.goals = [Goal()]
        self.goals=catgoals
    }
    
}
